
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'mfebrianto',
  applicationName: 'mclair',
  appUid: '2y79FCHbfTc6yZhtHf',
  orgUid: 'xpqJ0wxhsPQ9yZYtgG',
  deploymentUid: 'f8ce6173-2e7d-42f8-a718-c9bf19b27130',
  serviceName: 'quiz-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'quiz-api-dev-quizzes', timeout: 6 };

try {
  const userHandler = require('./src/functions/quizzes/handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.main, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}